<?php

$lang['no_record_found'] = "No Record Founds, Please wait as soon as coming...";
$lang['help_information'] = "Help Information";
$lang['sponsor_products'] = "Our Sponsor Products";
$lang['our_available_location'] = "Our Available Products Locations";
$lang['products'] = "Products";
$lang['services'] = "Services";
$lang['brand_shop'] = "Brand Shop";
$lang['wholesalers'] = "Wholesalers";
$lang['mall'] = "Shopping Mall";
$lang['super_store'] = "Super Store";
$lang['others'] = "Others";
$lang['all_categories_for'] = "All Categories For";
$lang['search_categories'] = "Shops,Categories,Locations etc";
$lang['search_products'] = "Products,Price,Categories,Locations etc";
$lang['categories'] = "Categories";
$lang['contactus'] = "Contact us";

/* Directories text*/

$lang['showing_result'] = "Showing result";
$lang['show'] = "Show";
$lang['refine_results'] = "Refine your results";
$lang['search'] = "Search";
$lang['choice_category'] = "Choice category";
$lang['choice_location'] = "Choice location";
$lang['no_records'] = "No Records found, please try again!";
$lang['tk'] = "Tk.";

