<?php
$lang['service_list'] = "List of services";
$lang['add_service'] = "Add New Service";
$lang['service'] = "Service";
$lang['service_info'] = "Service info";
$lang['setup_website'] = "Are You interest setup website?";
$lang['add_service'] = "Add/Edit Service";
$lang['service_type'] = "Service type";
$lang['classified_store'] = "Type of classified";
$lang['classified'] = "Classified";
$lang['listing_type'] = "Listing type";
$lang['listing'] = "Listing";
$lang['product'] = "Product Details";
$lang['all_upload'] = "All Upload";
$lang['product_specification'] = "Product specification";
$lang['product_image'] = "Image";
$lang['product_gallery'] = "Gallery";
$lang['gallery'] = "Gallery";
$lang['edit'] = "Edit";
$lang['delete_gallery'] = "Delete Gallery";
$lang['designation'] = "Designation";
$lang['select_one'] = "Select one";

