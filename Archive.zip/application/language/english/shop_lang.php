<?php
/* Start top menu sellers */

$lang['add_shop'] = "Modify Shop Information";

