<?php
/* Start Shopping mall */
$lang['mall_list'] = "Mall list";
$lang['mall_under_list'] = "Mall Under Shop List";
$lang['add_mall'] = "Add New shoppingmall";
$lang['mall_name'] = "Mall name";
$lang['mall_help'] = "Mall help";
$lang['mall_details'] = "Mall details";
$lang['shop_listing'] = "Shop list";
$lang['mall_info'] = "Mall info";
$lang['contact_name'] = "Contact name";
$lang['mobile_no'] = "Mobile no";
$lang['disclaimer'] = "Disclaimer";
$lang['mall_about'] = "About mall";
$lang['open_time'] = "Open Time";
$lang['close_time'] = "Close Time";
$lang['weekly_close'] = "Weekly Close Day";
$lang['car_parking'] = "Car Parking";
$lang['parking_capacity'] = "Parking Capacity";
$lang['escalator'] = "Escalator";
$lang['lift'] = "Lift";
$lang['air_condition'] = "Air Condition";
$lang['prayer_place'] = "Prayer Place";
$lang['security'] = "Security";
$lang['other_facalities'] = "Other Facalities";
$lang['about_us'] = "About us";
$lang['mall_disclaimer'] = "Shopping mall disclaimer view";
$lang['sponsor'] = "Sponsor";
$lang['advertisment'] = "Advertisement";
$lang['advertisment_list'] = "Advertisement list";
$lang['sponsor_setting'] = "Sponsor settings";
$lang['sponsor_list'] = "Sponsor list";
$lang['list_of_shop'] = "List of shop";
$lang['advertisment_position'] = "Position";
$lang['add_advertisement'] = "Add";
$lang['position'] = "Position";
$lang['advertisment_help'] = "Advertisement image must be";
$lang['alternative_advertisment'] = "Alternative";
$lang['advertisment_url'] = "Advertisment URL";
$lang['advertisment_url_help'] = "only add domain name & target page path(ie:domain name/target path)";
$lang['sponsor_url_help'] = "only add domain name & target page path(ie:domain name/target path)";
$lang['ordering'] = "Ordering";
$lang['sponsor_url'] = "Sponsor URL";


